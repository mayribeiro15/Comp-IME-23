# Battleship

Youtube video of the game: https://youtu.be/0Oz5GRuAzJU

It is a battleship game made in java. It uses drag and drop for placing and moving ships. The size of the grid, and the size and amount of ships that can be placed are all fully customizable via the main menu.

This was originally made as part of a group project in college, but it is completely different now than what it was at the end of the class. 
