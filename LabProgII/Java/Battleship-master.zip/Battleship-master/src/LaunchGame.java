
public class LaunchGame{
	public static void main(String[] args) {
		new GameLogic().setUpWindow();
	}
}
